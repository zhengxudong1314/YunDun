package com.dahua.searchandwarn.model;

/**
 * 创建： ZXD
 * 日期 2018/5/15
 * 功能：
 */

public class SW_StaticRequest {
    private double similarity;
    private String imageBase64;
    private String operator;

    public double getSimilarity() {
        return similarity;
    }

    public void setSimilarity(double similarity) {
        this.similarity = similarity;
    }

    public String getImageBase64() {
        return imageBase64;
    }

    public void setImageBase64(String imageBase64) {
        this.imageBase64 = imageBase64;
    }

    public String getOperator() {
        return operator;
    }

    public void setOperator(String operator) {
        this.operator = operator;
    }
}
