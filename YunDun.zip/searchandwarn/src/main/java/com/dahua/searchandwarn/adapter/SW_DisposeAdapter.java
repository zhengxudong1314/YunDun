package com.dahua.searchandwarn.adapter;

import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.support.annotation.Nullable;
import android.view.View;
import android.widget.LinearLayout;

import com.chad.library.adapter.base.BaseQuickAdapter;
import com.chad.library.adapter.base.BaseViewHolder;
import com.dahua.searchandwarn.R;
import com.dahua.searchandwarn.model.SW_HistoryWarnBean;
import com.dahua.searchandwarn.modules.warning.activity.SW_WarningDetailsActivity;
import com.dahua.searchandwarn.utils.ToastUtils;

import java.util.List;

/**
 * 创建： ZXD
 * 日期 2018/5/9
 * 功能：
 */

public class SW_DisposeAdapter extends BaseQuickAdapter<SW_HistoryWarnBean.DataBean, BaseViewHolder> implements View.OnClickListener {
    private Context context;
    private SW_HistoryWarnBean.DataBean bean;

    public SW_DisposeAdapter(Context context, int layoutResId, @Nullable List<SW_HistoryWarnBean.DataBean> data) {
        super(layoutResId, data);
        this.context = context;
    }

    @Override
    protected void convert(BaseViewHolder helper, SW_HistoryWarnBean.DataBean item) {
        this.bean = item;
        int position = helper.getAdapterPosition();
        helper.setText(R.id.tv_time, item.getSaveTime())
                .setText(R.id.tv_site, item.getDeviceName())
                .setText(R.id.tv_id, item.getFaceName());
        LinearLayout tvDetails = helper.getView(R.id.tv_details);
        LinearLayout tvLocation = helper.getView(R.id.tv_location);
        tvDetails.setOnClickListener(this);
        tvLocation.setOnClickListener(this);
        LinearLayout ll_bg = helper.getView(R.id.ll_bg);
        if (position%2==0){
            ll_bg.setBackgroundColor(context.getResources().getColor(R.color.tvLightBlue));
        }else {
            ll_bg.setBackgroundColor(context.getResources().getColor(R.color.colorWhite));
        }
    }

    @Override
    public void onClick(View v) {
        int i = v.getId();
        if (i == R.id.tv_details) {
            Intent intent = new Intent(context, SW_WarningDetailsActivity.class);
            intent = new Intent(context, SW_WarningDetailsActivity.class);
            intent.putExtra("alarmId", "6da903098b7e4f9bb271f14a90ed7ac2");
            context.startActivity(intent);
            ToastUtils.showShort("详情");
        } else if (i == R.id.tv_location) {
            Intent intent = new Intent();
            intent.setComponent(new ComponentName("com.mm.dss.map", "com.mm.dss.map.BaiduMapActivity"));
            intent.putExtra("longitude", bean.getDeviceX());//经度
            intent.putExtra("latitued", bean.getDeviceY());//纬度
            intent.putExtra("name", "dahua");
            //context.startActivity(intent);
            ToastUtils.showShort(bean.getDeviceX() + "-----" + bean.getDeviceY());
        }
    }


}
