package com.dahua.searchandwarn.modules.facesearching.activity;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.support.annotation.NonNull;
import android.util.Base64;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.PopupWindow;
import android.widget.TextView;

import com.bigkoo.pickerview.builder.TimePickerBuilder;
import com.bigkoo.pickerview.listener.OnTimeSelectListener;
import com.bigkoo.pickerview.view.TimePickerView;
import com.bumptech.glide.Glide;
import com.dahua.searchandwarn.R;
import com.dahua.searchandwarn.utils.LogUtils;
import com.dahua.searchandwarn.utils.TimeConstants;
import com.dahua.searchandwarn.utils.TimeUtils;
import com.jph.takephoto.app.TakePhoto;
import com.jph.takephoto.app.TakePhotoActivity;
import com.jph.takephoto.app.TakePhotoImpl;
import com.jph.takephoto.model.CropOptions;
import com.jph.takephoto.model.InvokeParam;
import com.jph.takephoto.model.TContextWrap;
import com.jph.takephoto.model.TResult;
import com.jph.takephoto.permission.PermissionManager;
import com.jph.takephoto.permission.TakePhotoInvocationHandler;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.text.SimpleDateFormat;
import java.util.Date;

public class SW_FaceSearchingActivity extends TakePhotoActivity implements View.OnClickListener {

    private ImageView ivBack;
    private ImageView ivFace;
    private LinearLayout llFace;
    private TextView tvTitle;
    private EditText etSimilarity;
    private TextView tvStartTime;
    private TextView tvEndTime;
    private TextView tvSite;
    private TextView tvSure;
    private TextView tvReset;
    private String strStratTime;
    private String strEndTime;
    private InvokeParam invokeParam;
    private TakePhoto takePhoto;
    private Uri imageUri;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.sw_activity_face_searching);
        initView();

        tvTitle.setText("人脸检索");
        tvStartTime.setText(strStratTime);
        tvEndTime.setText(strEndTime);
        etSimilarity.setText("85");

    }

    @Override
    public void takeSuccess(TResult result) {
        super.takeSuccess(result);
        LogUtils.e("takeSuccess");

        String iconPath = result.getImage().getOriginalPath();
        LogUtils.e(iconPath);
        Glide.with(this).load(iconPath).into(ivFace);
        llFace.setVisibility(View.GONE);
        ivFace.setVisibility(View.VISIBLE);
    }

    @Override
    public void takeFail(TResult result, String msg) {
        super.takeFail(result, msg);
        LogUtils.e("takeFail");
    }

    @Override
    public void takeCancel() {
        super.takeCancel();
        LogUtils.e("takeCancel");
    }
    @Override
    public PermissionManager.TPermissionType invoke(InvokeParam invokeParam) {
        PermissionManager.TPermissionType type=PermissionManager.checkPermission(TContextWrap.of(this),invokeParam.getMethod());
        if(PermissionManager.TPermissionType.WAIT.equals(type)){
            this.invokeParam=invokeParam;
        }
        return type;
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        PermissionManager.TPermissionType type=PermissionManager.onRequestPermissionsResult(requestCode,permissions,grantResults);
        PermissionManager.handlePermissionsResult(this,type,invokeParam,this);
    }
    public TakePhoto getTakePhoto(){
        if (takePhoto==null){
            takePhoto= (TakePhoto) TakePhotoInvocationHandler.of(this).bind(new TakePhotoImpl(this,this));
        }
        return takePhoto;
    }

    private CropOptions getCropOptions() {
        CropOptions.Builder builder=new CropOptions.Builder();
        builder.setAspectX(400).setAspectY(400);//裁剪时的尺寸比例
        builder.setWithOwnCrop(false);//s使用第三方还是takephoto自带的裁剪工具
        return builder.create();
    }
    @Override
    protected void onSaveInstanceState(Bundle outState) {
        getTakePhoto().onSaveInstanceState(outState);
        super.onSaveInstanceState(outState);
    }

    private void initView() {
        takePhoto = getTakePhoto();
        ivBack = (ImageView) findViewById(R.id.iv_back);
        ivFace = (ImageView) findViewById(R.id.iv_face);
        llFace = (LinearLayout) findViewById(R.id.ll_face);
        tvTitle = (TextView) findViewById(R.id.tv_title);
        etSimilarity = (EditText) findViewById(R.id.et_similarity);
        tvStartTime = (TextView) findViewById(R.id.tv_start_time);
        tvEndTime = (TextView) findViewById(R.id.tv_end_time);
        tvSite = (TextView) findViewById(R.id.tv_site);
        tvSure = (TextView) findViewById(R.id.tv_sure);
        tvReset = (TextView) findViewById(R.id.tv_reset);
        Date date = TimeUtils.getDateByNow(get30DayMillis(), TimeConstants.MSEC);
        strStratTime = TimeUtils.date2String(date, new SimpleDateFormat("YYYY-MM-dd 00:00:00"));
        strEndTime = TimeUtils.getNowString(new SimpleDateFormat("YYYY-MM-dd HH:mm:ss"));
        ivBack.setOnClickListener(this);
        tvStartTime.setOnClickListener(this);
        tvEndTime.setOnClickListener(this);
        tvSite.setOnClickListener(this);
        tvSure.setOnClickListener(this);
        tvReset.setOnClickListener(this);
        llFace.setOnClickListener(this);
        ivFace.setOnClickListener(this);
        etSimilarity.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View v, boolean hasFocus) {
                if (hasFocus) {
                    etSimilarity.setText("");
                }
            }
        });

    }

    @Override
    public void onClick(View v) {
        int i = v.getId();

        if (i == R.id.iv_back) {
            finish();
        } else if (i == R.id.iv_face) {
            showPopupWindow();
        } else if (i == R.id.ll_face) {
            showPopupWindow();

        } else if (i == R.id.tv_start_time) {
            getStartTimePicker(tvStartTime);
        } else if (i == R.id.tv_end_time) {
            getEndStartTimePicker(tvEndTime);
        } else if (i == R.id.et_similarity) {

        } else if (i == R.id.tv_site) {

        } else if (i == R.id.tv_sure) {

        } else if (i == R.id.tv_reset) {

        }

    }

    private void showPopupWindow() {
        View view = LayoutInflater.from(this).inflate(R.layout.sw_view_popup_photo, null);
        TextView tv_camera = (TextView) view.findViewById(R.id.tv_camera);
        TextView tv_photo = (TextView) view.findViewById(R.id.tv_photo);
        TextView tv_cancle = (TextView) view.findViewById(R.id.tv_cancle);
        final PopupWindow popupWindow = new PopupWindow(view, ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        popupWindow.setBackgroundDrawable(getResources().getDrawable(android.R.color.transparent));
        popupWindow.setOutsideTouchable(true);
        popupWindow.setFocusable(true);
        //拍照
        popupWindow.showAtLocation(getWindow().getDecorView(), Gravity.BOTTOM, 0, 0);
        tv_camera.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                popupWindow.dismiss();
                imageUri = getImageUrl();
                takePhoto.onPickFromCaptureWithCrop(imageUri,getCropOptions());
            }
        });
        tv_photo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                popupWindow.dismiss();
                imageUri = getImageUrl();
                takePhoto.onPickFromGalleryWithCrop(imageUri,getCropOptions());
            }
        });
        tv_cancle.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                popupWindow.dismiss();
            }
        });
    }

    private Uri getImageUrl() {
        File file=new File(Environment.getExternalStorageDirectory(),
                "/temp"+ System.currentTimeMillis()+".jpg");
        if (!file.getParentFile().exists())file.getParentFile().mkdirs();
        Uri imgUri = Uri.fromFile(file);
        return imgUri;
    }


    private void getStartTimePicker(final TextView tvTime) {
        TimePickerView pvTime = new TimePickerBuilder(SW_FaceSearchingActivity.this, new OnTimeSelectListener() {
            @Override
            public void onTimeSelect(Date date, View v) {
                tvTime.setText(TimeUtils.date2String(date, new SimpleDateFormat("YYYY-MM-dd HH:mm:ss")));
            }
        }).setType(new boolean[]{true, true, true, true, true, true})
                .build();
        pvTime.show();
    }

    private void getEndStartTimePicker(final TextView tvTime) {
        TimePickerView pvTime = new TimePickerBuilder(SW_FaceSearchingActivity.this, new OnTimeSelectListener() {
            @Override
            public void onTimeSelect(Date date, View v) {
                tvTime.setText(TimeUtils.date2String(date, new SimpleDateFormat("YYYY-MM-dd HH:mm:ss")));
            }
        }).setType(new boolean[]{true, true, true, true, true, true})
                .build();
        pvTime.show();
    }

    private long get30DayMillis() {

        return -30 * 24 * 60 * 60 * 1000l;
    }

    //隐藏软键盘同时使EditText失去焦点
    @Override
    public boolean dispatchTouchEvent(MotionEvent ev) {
        if (ev.getAction() == MotionEvent.ACTION_DOWN) {
            View v = getCurrentFocus();
            if (isShouldHideInput(v, ev)) {
                InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
                if (imm != null) {
                    assert v != null;
                    imm.hideSoftInputFromWindow(v.getWindowToken(), 0);

                    v.clearFocus();
                }
            }
            return super.dispatchTouchEvent(ev);
        }
        // 必不可少，否则所有的组件都不会有TouchEvent了
        return getWindow().superDispatchTouchEvent(ev) || onTouchEvent(ev);
    }

    private boolean isShouldHideInput(View v, MotionEvent event) {
        if (v != null && (v instanceof EditText)) {
            int[] leftTop = {0, 0};
            //获取输入框当前的location位置
            v.getLocationInWindow(leftTop);
            int left = leftTop[0];
            int top = leftTop[1];
            int bottom = top + v.getHeight();
            int right = left + v.getWidth();
            return !(event.getX() > left && event.getX() < right
                    && event.getY() > top && event.getY() < bottom);
        }
        return false;
    }
    //图片转换成base64
    private String encode(String path) {
        //decode to bitmap
        Bitmap bitmap = BitmapFactory.decodeFile(path);
        //convert to byte array
        ByteArrayOutputStream baos = new ByteArrayOutputStream();
        bitmap.compress(Bitmap.CompressFormat.PNG, 100, baos);
        byte[] bytes = baos.toByteArray();

        //base64 encode
        byte[] encode = Base64.encode(bytes,Base64.DEFAULT);
        String encodeString = new String(encode);
        return encodeString;
    }

    private Bitmap decode(String path) {
        byte[] bytes = Base64.decode(path, Base64.DEFAULT);
        Bitmap bitmap = BitmapFactory.decodeByteArray(bytes, 0, bytes.length);
        return bitmap;
    }
}
