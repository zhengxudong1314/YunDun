package com.dahua.searchandwarn.modules.facesearching.activity;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.dahua.searchandwarn.R;

public class SW_StaticDialogActivity extends AppCompatActivity {

    private ImageView ivImg;
    private TextView tvName;
    private TextView tvSimilarity;
    private TextView tvAge;
    private TextView tvSex;
    private TextView tvAndi;
    private TextView tvCardId;
    private TextView tvHuji;
    private TextView tvAddress;
    private TextView tvClose;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.sw_activity_dialog_static);
        setFinishOnTouchOutside(false);
        initView();
        Glide.with(this).load("").into(ivImg);
        tvSimilarity.setText("");
        tvName.setText("");
        tvCardId.setText("");
        tvSex.setText("");
        tvAge.setText("");
        tvAndi.setText("");
        tvHuji.setText("");
        tvAddress.setText("");
        tvClose.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
    }

    private void initView() {
        ivImg = (ImageView) findViewById(R.id.iv_img);
        tvName = (TextView) findViewById(R.id.tv_name);
        tvSimilarity = (TextView) findViewById(R.id.tv_similarity);
        tvAge = (TextView) findViewById(R.id.tv_age);
        tvSex = (TextView) findViewById(R.id.tv_sex);
        tvAndi = (TextView) findViewById(R.id.tv_andi);
        tvCardId = (TextView) findViewById(R.id.tv_cardId);
        tvHuji = (TextView) findViewById(R.id.tv_huji);
        tvAddress = (TextView) findViewById(R.id.tv_address);
        tvClose = (TextView) findViewById(R.id.tv_close);
    }
}
