package com.dahua.searchandwarn.service;

import android.app.Service;
import android.content.Intent;
import android.os.IBinder;
import android.support.annotation.Nullable;

import org.eclipse.paho.client.mqttv3.MqttClient;
import org.eclipse.paho.client.mqttv3.MqttConnectOptions;

/**
 * 作用：
 * 作者： 郑旭东
 * 日期：2018/5/17
 */

public class MqttService extends Service  {
    public static final String HOST = "tcp://192.168.1.3:61613";
    public static final String TOPIC = "toclient/124";
    private static final String clientid = "client124";
    private MqttClient client;
    private MqttConnectOptions options;
    private String userName = "admin";
    private String passWord = "password";

    @Override
    public void onCreate() {
        super.onCreate();

    }


    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }


}
