package com.dahua.searchandwarn.modules.facesearching.activity;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.TextView;

import com.dahua.searchandwarn.R;

public class SW_DynamicDialogActivity extends AppCompatActivity {
    private TextView tvClose;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.sw_activity_dynamic_dialog);
        setFinishOnTouchOutside(false);
        initView();
        tvClose.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
    }

    private void initView() {
        tvClose = (TextView) findViewById(R.id.tv_close);
    }
}
